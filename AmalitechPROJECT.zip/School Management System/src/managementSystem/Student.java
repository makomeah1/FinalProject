package managementSystem;

import java.util.Scanner;

public class Student {
	
private	String FirstName;
private	String LastName;
private String studentID;
private  int Grade;
private int TutionFee;
private  int feesPaid;
private int id=1000;

//A method to get the total tuition fee to be paid.


//A method to pay tuition of students.
public int payTutionFee(int tutionFee) {
	return feesPaid+=tutionFee;
	 
}
public int getFeesPaid() {
	return feesPaid;
}
public int getTutionBalance() {
	return TutionFee-=getFeesPaid();
	
}
public Student(){
	Scanner Sc= new Scanner(System.in);
	System.out.print("Please Enter First name of student: ");	
	this.FirstName=Sc.nextLine();
	System.out.print("Please Enter Your Last name of Student: ");
	this.LastName=Sc.nextLine();
	do {
	System.out.println("Please Enter Grade to be admitted in: ");
	System.out.println("1) Grade 1\n"+ "2) Grade 2\n" +"3) Grade 3\n"+"4) Grade 4");
	 this.Grade=Sc.nextInt();
	if(this.Grade<1||this.Grade>4) {
	System.out.println("Please enter a valid Grade from (1-4)");
	}else{
		System.out.println("Welcome "+getFirstName()+",you are successufully admitted into Grade"+getGrade()+ " with a studentId "+ getStudentID());
	}	
	
	}
	  while (this.Grade<1||this.Grade > 4);
	
	setStudentID();
		
}
public String getStudentID() {
	return this.studentID;
}
private void setStudentID() {
 id++;
 this.studentID = Grade+""+id;

}
public String getFirstName() {
	return FirstName;
}

public void setFirstName(String firstName) {
	FirstName = firstName;
}
public String getLastName() {
	return LastName;
}

public void setLastName(String lastName) {
	LastName = lastName;
}
public void setGrade(int grade) {
	Grade = grade;
}
public  int getGrade() {
	return Grade;
}
public int getTutionFee() {
	
	if (this.getGrade()==1) {
		return TutionFee=800;
	}
	else if (this.getGrade()==2) {
		return TutionFee=700;
	}
	else if (this.getGrade()==3) {
		return TutionFee=600;
	}
	else if (this.getGrade()==4) {
		return TutionFee=900;
	}
	 return 0;
}

@Override
public String toString() {
	return "\n\n"+ "Name=" + FirstName+ " " + LastName +"\n"+"StudentID="+getStudentID()+"\n"+"Grade="+ Grade+"\n" + "TutionFee=" + getTutionFee()+"\n"
			+ "FeesPaid=" + feesPaid+"\n" + "TutionBalance="
			+ getTutionBalance();
}	
}