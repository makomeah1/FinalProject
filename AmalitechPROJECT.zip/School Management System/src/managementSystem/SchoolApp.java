package managementSystem;

import java.util.ArrayList;
import java.util.List;

public class SchoolApp {
	public static void main(String[] args) {
		Teacher lissy= new Teacher();
		Teacher Antoine= new Teacher();
		Teacher Ezra= new Teacher();
		List<Teacher>teacherslist= new ArrayList<>();
		teacherslist.add(Ezra);
		Ezra.setExtrahousworked(20);
		Ezra.setTakeHomePaid(1200);
		teacherslist.add(Antoine);
	    Antoine.setExtrahousworked(21);
		Antoine.setTakeHomePaid(2000);
		teacherslist.add(lissy);
		lissy.setTakeHomePaid(2100);
		
		Student Akomeah = new Student();
		Student Tamasha = new Student();
		Student rockson = new Student();
		
		List<Student>studentlist= new ArrayList<>();
		studentlist.add(Akomeah);
		Akomeah.payTutionFee(500);
		studentlist.add(rockson);
		rockson.payTutionFee(300);
		studentlist.add(Tamasha);
		
		School GIS = new School("GIS international", teacherslist,studentlist);
		System.out.println(GIS.getStudent());
		System.out.println(GIS.getTeacher());
		GIS.setOtherExpense(4500);
		GIS.setUtilitybill(3500);
		System.out.println(GIS.getUtilitybill());
		System.out.println(GIS.totalUtilityBill());
		System.out.println(GIS.toString());
		
		
	}
		
}
