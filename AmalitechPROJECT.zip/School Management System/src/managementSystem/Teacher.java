package managementSystem;

import java.util.Scanner;

public class Teacher {
	private String firstName;
	private String lastName;
	private int salary;
	private int extrahousworked;
	private int takeHomePaid;
	private int TeachersID;
	private static int TID=2000;
	

	public int getExtrahousworked() {
		return extrahousworked;
	}
	public void setExtrahousworked(int extrahousworked) {
		this.extrahousworked = extrahousworked;
	}
	
	
	
	public Teacher() {
		Scanner Sc= new Scanner(System.in);
		System.out.print("Please Enter First name of teacher: ");
		this.firstName=Sc.nextLine();
		System.out.print("Please Enter last name: ");
		this.lastName=Sc.nextLine();
		
		System.out.println("Enter salary of Teacher");
		this.salary=Sc.nextInt();
		
		 generateTeachersID();
					
	}
	
	public int getCommission() {
		return 30 *  getExtrahousworked() ;
	}
	
	
	public int takeHomePay() {
		return getSalary()+getCommission();
	}
	
	public int getTakeHomePay() {
		return takeHomePay();
	}
	
	public int setTakeHomePaid(int takehome) {
	return	this.takeHomePaid=takehome;
	
	}
	public int  getTakehomePaid() {
		return takeHomePaid;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getTeachersID() {
		return generateTeachersID() ;
	}
	public String generateTeachersID() {
		TID++;
	return firstName+TID;
	 
	}
	
	
	@Override
	public String toString() {
		return"\n\n"+ "Name :" + firstName +" "+ lastName +"\n" +"salary=" + salary
				+"\n" + "Extrahousworked=" + extrahousworked + 
				"\n"+"Commission = " + getCommission() +"\n"+ "TakeHomePay=" + takeHomePay() +"\n"+ "TeachersID="
				+ getTeachersID() + "\n"+"TakeHomePaid= "+getTakehomePaid() +" ]";
	}
	
	
	
	

}
