package managementSystem;

import java.util.List;

public class School {
private String name;
List <Teacher> teacher;
List <Student> student;	
private int utilitybill;
private int otherExpense;



public int getUtilitybill() {
	return utilitybill;
}
public void setUtilitybill(int utilitybill) {
	this.utilitybill = utilitybill;
}
public int totalUtilityBill() {
	int totalUtilityBill=0;
	return totalUtilityBill+=getUtilitybill();
}
public int totalOtherExp() {
	int totalOtherExp=0;
	return totalOtherExp+=getUtilitybill();
}


public int getOtherExpense() {
	return otherExpense;
}
public void setOtherExpense(int otherExpense) {
	this.otherExpense = otherExpense;
}


public School(String name,List<Teacher> teacher, List<Student> student) {
	this.teacher = teacher;
	this.student = student;
	this.name=name;
}
public List<Teacher> getTeacher() {
	return teacher;
}
public void addTeacher(Teacher teacher) {
	((List<Teacher>) teacher).add(teacher);
}
public List<Student> getStudent() {
	return student;
}
public void addStudent(Student student) {
	((List<Student>) student).add(student);
}
@Override
public String toString() {
	return "\n\n"+" School Name=" + name + "\n"+"Teacher=" + teacher +"\n\n"+ "Student=" + student +"\n\n" +"TotalUtilityBill=" + totalUtilityBill()
			+"\n" + "TotalOtherExp=" + totalOtherExp() + "]";
}


}
